# LyL Rotisería — pedidos por WhatsApp

Next.js 14 (App Router) + Tailwind CSS. Sin backend: el pedido se arma en el navegador y abre WhatsApp con el mensaje listo.

## Ejecutar
```
npm install
npm run dev     # http://localhost:3000
npm run build && npm start
```

## Editar
- `lib/config.js` → nombre y WhatsApp.
- `lib/products.js` → productos, precios, fotos y categorías. Las pizzas tienen `price: null` ("Consultar variedad y precio"); al poner un precio pasan a poder agregarse al carrito.
- `public/images/` → fotos.
- `lib/whatsapp.js` → formato del mensaje.

## Publicar
Subí la carpeta a GitHub e importala en Vercel o Netlify (build: `npm run build`). No requiere variables de entorno.

## Supabase (opcional)
No se usa. Para editar productos sin tocar código, `PRODUCTS` en `lib/products.js` puede reemplazarse por una consulta a una tabla `products` (usando solo la clave pública `anon` con RLS de solo lectura).
