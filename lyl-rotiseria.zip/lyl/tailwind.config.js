/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0d0d0d", coal: "#1a1614", card: "#221c19",
        brand: { DEFAULT: "#d8141c", dark: "#a50d14" },
        gold: "#f2b632", cream: "#fff4e0", mut: "#c9b9a3",
      },
      fontFamily: { display: ["var(--font-anton)", "Impact", "sans-serif"], sans: ["var(--font-dm)", "system-ui", "sans-serif"] },
      keyframes: {
        rise: { from: { opacity: 0, transform: "translateY(22px)" }, to: { opacity: 1, transform: "none" } },
        pop: { "0%": { transform: "scale(1)" }, "40%": { transform: "scale(1.25)" }, "100%": { transform: "scale(1)" } },
      },
      animation: { rise: "rise .8s both", pop: "pop .4s" },
    },
  },
  plugins: [],
};
