"use client";
import { useState } from "react";
import { money, buildMessage, waLink } from "../lib/whatsapp";

const field = "w-full rounded-xl border-2 border-[#4a3d36] bg-ink px-3 py-3 text-cream outline-none focus:border-gold";
const Err = ({ t }) => (t ? <p className="mt-1 text-sm text-red-400">{t}</p> : null);

export default function CartDrawer({ open, onClose, cart, total, change, remove, clear, onMenu }) {
  const [step, setStep] = useState("cart");
  const [f, setF] = useState({ name: "", delivery: "Retiro", location: "", notes: "" });
  const [err, setErr] = useState({});
  const [geoMsg, setGeoMsg] = useState("");
  const set = (k, v) => { setF((s) => ({ ...s, [k]: v })); setErr((e) => ({ ...e, [k]: "" })); };
  const close = () => { onClose(); setTimeout(() => setStep("cart"), 300); };

  const geo = () => {
    if (!navigator.geolocation) return setGeoMsg("Tu navegador no permite obtener la ubicación. Escribí tu dirección.");
    setGeoMsg("Buscando tu ubicación…");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const link = `https://maps.google.com/?q=${p.coords.latitude},${p.coords.longitude}`;
        set("location", (f.location.trim() ? f.location.trim() + "\n" : "") + link);
        setGeoMsg("");
      },
      () => setGeoMsg("No pudimos obtener tu ubicación. Escribí tu dirección."),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const send = () => {
    const e = {};
    if (f.name.trim().split(/\s+/).filter(Boolean).length < 2) e.name = "Ingresá tu nombre y apellido.";
    if (f.delivery === "Envío" && f.location.trim().length < 5) e.location = "Ingresá tu ubicación o dirección para el envío.";
    setErr(e);
    if (Object.keys(e).length || !cart.length) return;
    const url = waLink(buildMessage({ ...f, items: cart, total }));
    const w = window.open(url, "_blank");
    if (!w) window.location.href = url;
  };

  return (
    <>
      <div onClick={close} className={`fixed inset-0 z-50 bg-black/65 transition ${open ? "opacity-100" : "pointer-events-none opacity-0"}`} />
      <aside role="dialog" aria-label="Tu pedido" className={`fixed inset-x-0 bottom-0 z-[60] flex max-h-[92dvh] flex-col rounded-t-3xl border-t-4 border-brand bg-coal transition duration-300 md:inset-y-0 md:left-auto md:right-0 md:max-h-none md:w-[440px] md:rounded-none md:border-l-4 md:border-t-0 ${open ? "translate-y-0 md:translate-x-0" : "translate-y-full md:translate-y-0 md:translate-x-full"}`}>
        <div className="flex items-center justify-between border-b border-white/10 p-4">
          <h2 className="font-display text-3xl">{step === "cart" ? "Tu pedido" : "Tus datos"}</h2>
          <button onClick={close} aria-label="Cerrar" className="h-10 w-10 rounded-full bg-card">✕</button>
        </div>

        {step === "cart" ? (
          <>
            <div className="flex-1 overflow-y-auto p-4">
              {cart.length === 0 ? (
                <div className="py-10 text-center text-mut">
                  Tu pedido está vacío.
                  <button onClick={() => { close(); onMenu(); }} className="mt-4 block w-full rounded-full bg-brand py-3 font-bold text-cream">VER MENÚ</button>
                </div>
              ) : cart.map((i) => (
                <div key={i.id} className="border-b border-white/10 py-3">
                  <div className="flex justify-between gap-3"><b className="font-medium">{i.name}</b><span className="flex-none text-sm text-mut">{money(i.price)} c/u</span></div>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <div className="flex items-center rounded-full bg-ink">
                      <button aria-label="Menos" onClick={() => change(i.id, -1)} className="h-9 w-9 text-lg">−</button>
                      <span className="min-w-6 text-center font-bold">{i.qty}</span>
                      <button aria-label="Más" onClick={() => change(i.id, 1)} className="h-9 w-9 text-lg">+</button>
                    </div>
                    <span className="font-bold text-gold">Subtotal {money(i.price * i.qty)}</span>
                    <button onClick={() => remove(i.id)} className="text-sm text-mut underline">Eliminar</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="grid gap-3 border-t border-white/10 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center justify-between text-xl">TOTAL <b className="font-display text-3xl text-gold">{money(total)}</b></div>
              <button disabled={!cart.length} onClick={() => setStep("form")} className="rounded-full bg-brand py-4 font-bold shadow-[0_6px_0_#a50d14] transition active:translate-y-1 active:shadow-none disabled:opacity-40">REALIZAR PEDIDO</button>
              {cart.length > 0 && <button onClick={() => confirm("¿Vaciar todo el pedido?") && clear()} className="text-sm text-mut underline">Vaciar carrito</button>}
            </div>
          </>
        ) : (
          <>
            <div className="flex-1 space-y-4 overflow-y-auto p-4">
              <div>
                <label htmlFor="nm" className="mb-1 block font-bold">Nombre y apellido</label>
                <input id="nm" autoComplete="name" value={f.name} onChange={(e) => set("name", e.target.value)} placeholder="Ej: Juan Pérez" className={field} />
                <Err t={err.name} />
              </div>
              <div>
                <p className="mb-1 font-bold">Pedido</p>
                <ul className="rounded-xl bg-ink p-3 text-sm">
                  {cart.map((i) => <li key={i.id} className="flex justify-between gap-2 py-0.5"><span>{i.name} x {i.qty}</span><span>{money(i.price * i.qty)}</span></li>)}
                </ul>
              </div>
              <div>
                <p className="mb-1 font-bold">Retiro o envío</p>
                <div className="grid grid-cols-2 gap-3">
                  {[["Retiro", "🏃 Paso a retirar"], ["Envío", "🛵 Envío"]].map(([v, l]) => (
                    <label key={v} className={`cursor-pointer rounded-xl border-2 p-3 text-center transition ${f.delivery === v ? "border-gold bg-[#3a1a14] font-bold text-gold" : "border-[#4a3d36] bg-ink"}`}>
                      <input type="radio" name="ent" className="sr-only" checked={f.delivery === v} onChange={() => set("delivery", v)} />{l}
                    </label>
                  ))}
                </div>
              </div>
              {f.delivery === "Envío" && (
                <div className="animate-rise">
                  <p className="mb-2 rounded-lg border-l-4 border-gold bg-[#3a1a14] p-3 text-sm">Para realizar el envío, enviá tu ubicación o escribí tu dirección.</p>
                  <label htmlFor="loc" className="mb-1 block font-bold">Ubicación / dirección</label>
                  <textarea id="loc" rows={3} value={f.location} onChange={(e) => set("location", e.target.value)} placeholder="Calle, número, barrio y referencias" className={field} />
                  <button type="button" onClick={geo} className="mt-2 w-full rounded-full bg-gold py-3 font-bold text-black">📍 Usar mi ubicación actual</button>
                  {geoMsg && <p className="mt-1 text-sm text-mut">{geoMsg}</p>}
                  <Err t={err.location} />
                </div>
              )}
              <div>
                <label htmlFor="nt" className="mb-1 block font-bold">¿Querés alguna modificación en tu pedido? <span className="font-normal text-mut">(opcional)</span></label>
                <textarea id="nt" rows={3} value={f.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Sin cebolla, agregar queso, etc." className={field} />
              </div>
            </div>
            <div className="grid gap-3 border-t border-white/10 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center justify-between text-xl">COSTO TOTAL <b className="font-display text-3xl text-gold">{money(total)}</b></div>
              <button onClick={send} className="rounded-full bg-green-600 py-4 text-lg font-bold shadow-[0_6px_0_#14783a] transition active:translate-y-1 active:shadow-none">PEDIR POR WHATSAPP</button>
              <button onClick={() => setStep("cart")} className="text-sm text-mut underline">← Volver al pedido</button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
