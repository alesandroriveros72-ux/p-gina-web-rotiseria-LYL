"use client";
import { useEffect, useState } from "react";
import { BRAND } from "../lib/config";
import { CATEGORIES, PRODUCTS } from "../lib/products";
import { money, waLink } from "../lib/whatsapp";
import ProductCard from "./ProductCard";
import CartDrawer from "./CartDrawer";

const label = (p) => (p.description ? `${p.name} (${p.description.toLowerCase()})` : p.name);

export default function Shop() {
  const [cart, setCart] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [active, setActive] = useState("promos");
  const [bump, setBump] = useState(0);

  useEffect(() => {
    try { setCart(JSON.parse(localStorage.getItem("lyl-cart") || "[]")); } catch {}
    setLoaded(true);
  }, []);
  useEffect(() => {
    if (loaded) try { localStorage.setItem("lyl-cart", JSON.stringify(cart)); } catch {}
  }, [cart, loaded]);

  // Aparición al hacer scroll + categoría activa
  useEffect(() => {
    const rv = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); rv.unobserve(e.target); } }), { threshold: 0.08 });
    document.querySelectorAll("[data-reveal]").forEach((el) => rv.observe(el));
    const spy = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)), { rootMargin: "-35% 0px -55% 0px" });
    CATEGORIES.forEach((c) => { const el = document.getElementById(c.id); if (el) spy.observe(el); });
    return () => { rv.disconnect(); spy.disconnect(); };
  }, []);

  useEffect(() => {
    const el = document.querySelector(`[data-chip="${active}"]`);
    const bar = el && el.parentElement;
    if (bar) bar.scrollTo({ left: el.offsetLeft - bar.clientWidth / 2 + el.offsetWidth / 2, behavior: "smooth" });
  }, [active]);

  const add = (p, qty) => {
    setCart((c) => c.some((i) => i.id === p.id)
      ? c.map((i) => (i.id === p.id ? { ...i, qty: i.qty + qty } : i))
      : [...c, { id: p.id, name: label(p), price: p.price, qty }]);
    setBump((b) => b + 1);
  };
  const change = (id, d) => setCart((c) => c.flatMap((i) => (i.id !== id ? [i] : i.qty + d < 1 ? [] : [{ ...i, qty: i.qty + d }])));
  const remove = (id) => setCart((c) => c.filter((i) => i.id !== id));
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const goMenu = () => { const el = document.getElementById("promos"); if (el) el.scrollIntoView({ behavior: "smooth" }); };

  return (
    <>
      <header className="sticky top-0 z-30 border-b-2 border-brand bg-ink/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
          <a href="#inicio" className="mr-auto flex items-center gap-2 font-display text-2xl">
            <img src="/images/logo.jpg" alt={`Logo ${BRAND.name}`} className="h-11 w-11 rounded-full border-2 border-gold object-cover" />
            {BRAND.name}
          </a>
          <nav className={`${menu ? "flex" : "hidden"} absolute left-0 right-0 top-16 flex-col border-b-2 border-brand bg-ink p-4 md:static md:flex md:flex-row md:border-0 md:p-0`} onClick={() => setMenu(false)}>
            {[["#inicio", "Inicio"], ["#promos", "Menú"], ["#promos", "Promociones"], ["#contacto", "Contacto"]].map(([h, t]) => (
              <a key={t} href={h} className="rounded-full px-4 py-3 font-medium transition hover:bg-brand md:py-2">{t}</a>
            ))}
          </nav>
          <button onClick={() => setOpen(true)} aria-label="Abrir carrito" className="relative h-11 w-11 rounded-full bg-card text-xl transition hover:scale-110">
            🛒<span key={bump} className="absolute -right-1 -top-1 grid h-5 min-w-5 animate-pop place-items-center rounded-full bg-gold text-xs font-bold text-black">{count}</span>
          </button>
          <button onClick={() => setMenu((m) => !m)} aria-label="Menú" className="h-11 w-11 rounded-full bg-card text-xl md:hidden">☰</button>
        </div>
      </header>

      <main>
        <section id="inicio" className="overflow-hidden bg-[radial-gradient(circle_at_80%_20%,#5a0c10,transparent_60%)]">
          <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 md:grid-cols-2 md:py-16">
            <div>
              <h1 className="animate-rise font-display text-5xl leading-none md:text-7xl">Comida casera, hecha para disfrutar</h1>
              <p className="mt-4 max-w-md animate-rise text-lg text-mut [animation-delay:.15s]">Hamburguesas, pizzas, empanadas, sándwiches y combos. Armá tu pedido y enviálo por WhatsApp.</p>
              <div className="mt-6 flex animate-rise flex-wrap gap-3 [animation-delay:.3s]">
                <a href="#promos" className="rounded-full bg-brand px-7 py-4 font-bold shadow-[0_6px_0_#a50d14] transition active:translate-y-1 active:shadow-none">VER MENÚ</a>
                <button onClick={() => (count ? setOpen(true) : goMenu())} className="rounded-full bg-gold px-7 py-4 font-bold text-black shadow-[0_6px_0_#b98712] transition active:translate-y-1 active:shadow-none">ARMAR MI PEDIDO</button>
              </div>
            </div>
            <img src="/images/hero.jpg" alt="Hamburguesa completa" className="aspect-[10/9] w-full animate-rise rounded-3xl border-4 border-gold object-cover shadow-2xl shadow-brand/40 [animation-delay:.2s]" />
          </div>
        </section>

        <div className="no-scrollbar sticky top-16 z-20 flex gap-2 overflow-x-auto border-b border-white/10 bg-ink/95 px-4 py-3 backdrop-blur md:justify-center">
          {CATEGORIES.map((c) => (
            <a key={c.id} href={`#${c.id}`} data-chip={c.id} className={`flex-none whitespace-nowrap rounded-full border-2 px-5 py-2.5 text-sm font-bold transition ${active === c.id ? "border-gold bg-brand" : "border-transparent bg-card hover:border-gold"}`}>
              {c.emoji} {c.title}
            </a>
          ))}
        </div>

        {CATEGORIES.map((c) => (
          <section key={c.id} id={c.id} className={`py-12 ${c.id === "promos" ? "border-y-4 border-gold bg-gradient-to-br from-brand to-brand-dark" : c.id === "empanadas" || c.id === "hamburguesas" ? "bg-coal" : ""}`}>
            <div className="mx-auto max-w-6xl px-4">
              <div className="flex items-center gap-3">
                <span className="grid h-14 w-14 place-items-center rounded-full border-2 border-gold bg-brand text-3xl">{c.emoji}</span>
                <h2 className="font-display text-4xl text-gold md:text-6xl">{c.title}</h2>
              </div>
              <div className="my-3 h-1 rounded bg-gradient-to-r from-gold via-brand to-transparent" />
              <p className="mb-6 text-mut">{c.subtitle}</p>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {PRODUCTS.filter((p) => p.category === c.id).map((p) => <ProductCard key={p.id} p={p} onAdd={add} />)}
              </div>
            </div>
          </section>
        ))}

        <section id="contacto" className="bg-coal py-12 text-center">
          <div className="mx-auto max-w-xl px-4">
            <h2 className="font-display text-4xl">Cómo pedir</h2>
            <ol className="mx-auto my-5 max-w-md list-decimal space-y-2 pl-6 text-left">
              <li>Elegí tus productos y tocá “Agregar al pedido”.</li>
              <li>Abrí el carrito, revisá cantidades y total.</li>
              <li>Tocá “Realizar pedido” y completá tus datos.</li>
              <li>Presioná “Pedir por WhatsApp” y enviá el mensaje.</li>
            </ol>
            <a target="_blank" rel="noopener" href={waLink()} className="inline-block rounded-full bg-green-600 px-8 py-4 font-bold shadow-[0_6px_0_#14783a]">PEDIR POR WHATSAPP</a>
          </div>
        </section>
      </main>

      <footer className="border-t-2 border-brand px-4 py-8 pb-28 text-center text-sm text-mut">
        <p className="font-display text-2xl text-cream">{BRAND.name} {BRAND.tagline}</p>
        <p className="mt-1">WhatsApp: {BRAND.phoneDisplay} · Pedidos por WhatsApp</p>
        <p className="mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1">{CATEGORIES.map((c) => <a key={c.id} href={`#${c.id}`} className="hover:text-gold">{c.title}</a>)}</p>
      </footer>

      <button onClick={() => setOpen(true)} key={bump} className="fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-4 right-24 z-40 max-w-md animate-pop rounded-full border-2 border-gold bg-brand px-4 py-4 text-left font-bold shadow-xl md:left-auto md:right-24">
        🛒 {count} producto{count === 1 ? "" : "s"} · {money(total)}
      </button>
      <a href={waLink()} target="_blank" rel="noopener" aria-label="WhatsApp" className="fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] right-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-green-600 text-3xl shadow-xl transition hover:scale-110">💬</a>

      <CartDrawer open={open} onClose={() => setOpen(false)} cart={cart} total={total} change={change} remove={remove} clear={() => setCart([])} onMenu={goMenu} />
    </>
  );
}
