"use client";
import { useState } from "react";
import { money, waLink } from "../lib/whatsapp";

export default function ProductCard({ p, onAdd }) {
  const [qty, setQty] = useState(1);
  const [done, setDone] = useState(false);
  const priced = typeof p.price === "number";

  const add = () => {
    onAdd(p, qty);
    setQty(1);
    setDone(true);
    setTimeout(() => setDone(false), 1100);
  };

  return (
    <article data-reveal className="group flex flex-col overflow-hidden rounded-3xl bg-card shadow-lg shadow-black/40 transition duration-300 hover:-translate-y-1 hover:shadow-brand/30">
      <div className="relative overflow-hidden">
        {p.badge && <span className="absolute left-3 top-3 z-10 rounded-full border border-gold bg-brand px-3 py-1 font-display text-sm tracking-wide">{p.badge}</span>}
        <img src={p.image} alt={p.name} loading="lazy" className="aspect-[4/3] w-full object-cover transition duration-500 group-hover:scale-105" />
      </div>
      <div className="flex flex-1 flex-col gap-3 p-4">
        <h3 className="text-lg font-bold leading-tight">{p.name}</h3>
        {p.description && <p className="-mt-1 text-sm text-mut">{p.description}</p>}
        {priced ? (
          <>
            <p className="font-display text-3xl text-gold">{money(p.price)}</p>
            <div className="mt-auto flex items-center gap-3">
              <div className="flex items-center rounded-full bg-ink">
                <button aria-label="Menos" onClick={() => setQty((q) => Math.max(1, q - 1))} className="h-10 w-10 text-xl hover:text-gold">−</button>
                <span className="min-w-6 text-center font-bold">{qty}</span>
                <button aria-label="Más" onClick={() => setQty((q) => Math.min(30, q + 1))} className="h-10 w-10 text-xl hover:text-gold">+</button>
              </div>
              <button onClick={add} className={`flex-1 rounded-full py-3 font-bold transition active:scale-95 ${done ? "bg-green-600" : "bg-brand hover:bg-red-600"}`}>
                {done ? "✓ Agregado" : "AGREGAR AL PEDIDO"}
              </button>
            </div>
          </>
        ) : (
          <>
            <p className="font-display text-xl text-gold">Consultar variedad y precio</p>
            <a target="_blank" rel="noopener" href={waLink("Hola! Quiero consultar variedades y precios de pizzas.")} className="mt-auto rounded-full bg-green-600 py-3 text-center font-bold transition hover:bg-green-500 active:scale-95">CONSULTAR POR WHATSAPP</a>
          </>
        )}
      </div>
    </article>
  );
}
