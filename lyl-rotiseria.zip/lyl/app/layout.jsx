import { Anton, DM_Sans } from "next/font/google";
import "./globals.css";

const anton = Anton({ weight: "400", subsets: ["latin"], variable: "--font-anton" });
const dm = DM_Sans({ subsets: ["latin"], variable: "--font-dm" });

export const metadata = {
  title: "LyL Rotisería — Pedí online",
  description: "Hamburguesas, empanadas, pizzas, sándwiches y combos. Pedidos por WhatsApp.",
};
export const viewport = { width: "device-width", initialScale: 1, themeColor: "#0d0d0d" };

export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${anton.variable} ${dm.variable}`}>
      <body>{children}</body>
    </html>
  );
}
